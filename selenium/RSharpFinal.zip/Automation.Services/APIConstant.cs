using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Automation.Services
{
    public class APIConstant
    {


        public const string GetBooksEndPoint = "BookStore/v1/Books";

        public const string GetBookEndPoint = "BookStore/v1/Book";

        public const string GetAccountEndPoint = "Account/v1/User";

        public const string GenerateTokenEndpoint = "login";

        public const string username = "cmtchuong";

        public const string password = "G@con123";

        public const string UserId = "d5298eac-065e-4f61-b675-221c1a9a040c";

        public const string AccountToken = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyTmFtZSI6ImNtdGNodW9uZyIsInBhc3N3b3JkIjoiR0Bjb24xMjMiLCJpYXQiOjE2Njk1MjY4NTF9.YryU4bpV2V6TXDQ0rTgHc-TOFM5ksXgIwZgGaojOpuo";

        
    }
}